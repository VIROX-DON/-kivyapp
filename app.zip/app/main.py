from kivy.app import App
from kivy.core.window import Window

Window.clearcolor = (0,0,.80,1)
Window.size = (715,1535)
class Main(App):
    def build(self):
        
        pass

if __name__ == '__main__':
    Main().run()